<footer id="footpage">
           
<?php
include('aside.php');
?>

        <div id="copyright">
            <p class="pagewidth">&copy; Greta 2020</p>
        </div>
    </footer>

</body>
</html>