<?php
include('header.php');
?>


    <main id="content">
      <div class="pagewidth">
          <div id="contact">
        <h1>Laissez nous un message</h1>
        <form action="envoimail.php" method="post">
            <fieldset>
                <legend>Vos coordonnées</legend>
                <div class="formcolumn">
                    <p><label for="nom">Nom </label>
                    <input type="text" name="nom" id="nom" placeholder="Tapez votre nom"></p>
                    <p><label for="prenom">Prénom </label>
                    <input type="text" name="prenom" id="prenom" placeholder="Tapez votre prénom"></p>
                    <p><label for="email">Email </label>
                    <input type="email" name="email" id="email" placeholder="email@domaine.com"></p>
                    <p><label for="tel">Téléphone </label>
                    <input type="tel" name="tel" id="tel" placeholder="06 06 06 06 06"></p>
                </div>
                <div class="formcolumn">
                    <p><label for="cp">Code Postal </label>
                    <input type="text" name="cp" id="cp" placeholder="Code postal"></p>
                    <p><label for="ville">Ville </label>
                    <input type="text" name="ville" id="ville" placeholder="Votre ville"></p>
                    <p><label for="adresse">Adresse </label>
                    <textarea name="adresse" id="adresse" placeholder="Votre adresse"></textarea></p>
                    <p><label for="pays">Pays </label>
                    <select name="pays" id="pays">
                        <option value="fr">France</option>
                        <option value="uk">Royaume Uni</option>
                        <option value="cn">Chine</option>
                    </select>
                    </p>
                </div>
            </fieldset>
            <fieldset>
                <legend>Votre message</legend>
                <p>Les cours qui vous intéressent:<br>
                <input type="checkbox" name="sport" id="sport" value="gym">
                <label for="gym" class="small-label">Gym</label>
                <input type="checkbox" name="sport" id="sport" value="muscu">
                <label for="muscu" class="small-label">Muscu</label>
                <input type="checkbox" name="sport" id="sport" value="pilates">
                <label for="pilates">Pilates</label></p>

                <p>
                <label for="message">Votre message </label>
                <textarea name="message" id="message" placeholder="Votre message"></textarea></p>
            </fieldset>

            <p class="button-form"><input type="submit" value="ENVOYER">
            <input type="reset" value="ANNULER"></p>

        </form>
        </div>

        <div id="map">
            <h2>Nous trouver</h2>
            <iframe id="carte" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d21504.803057926896!2d-2.7751648920269014!3d47.64361612044927!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xa95679d70af65df9!2sClub%20Gym!5e0!3m2!1sfr!2sfr!4v1604672059919!5m2!1sfr!2sfr" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
            <address>
                <strong>Club de gym</strong><br>
                17 rue de l'adresse<br>
                56000 VANNES
            </address>
            </div>

    </div>
    </main>

<?php
include('footer.php');
?>