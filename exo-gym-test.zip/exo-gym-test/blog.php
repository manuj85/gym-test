<?php
include('header.php');
?>


    <main id="content">
      <div class="pagewidth">



      <div id="menublog">
                <ul>
                    <li><a href="#" class="btmenublog">Tout</a></li>
                    <li><a href="#">Step</a></li>
                    <li><a href="#">Musculation</a></li>
                    <li><a href="#">Course</a></li>
                </ul>
      </div>





      <section id="articlesblog">

          <article class="postblog">
              <img src="images-gym/pic10.jpg" alt="cyclisme">
              <h3>Article 1</h3>
              <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit.Lorem ipsum dolor, sit amet consectetur adipisicing elit.</p>
              <div id="menublog">
                <ul>
                    <li><a href="#">+ d'info</a></li>
                </ul>
              </div>
          </article>
          <article class="postblog">
              <img src="images-gym/pic11.jpg" alt="cyclisme">
              <h3>Article 2</h3>
              <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit.Lorem ipsum dolor, sit amet consectetur adipisicing elit.</p>
              <div id="menublog">
                <ul>
                    <li><a href="#">+ d'info</a></li>
                </ul>
              </div>
          </article>
          <article class="postblog">
              <img src="images-gym/pic12.jpg" alt="cyclisme">
              <h3>Article 3</h3>
              <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit.Lorem ipsum dolor, sit amet consectetur adipisicing elit.</p>
              <div id="menublog">
                <ul>
                    <li><a href="#">+ d'info</a></li>
                </ul>
              </div>
          </article>
          <article class="postblog">
              <img src="images-gym/pic13.jpg" alt="cyclisme">
              <h3>Article 4</h3>
              <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit.Lorem ipsum dolor, sit amet consectetur adipisicing elit.</p>
              <div id="menublog">
                <ul>
                    <li><a href="#">+ d'info</a></li>
                </ul>
              </div>
          </article>
          <article class="postblog">
              <img src="images-gym/pic14.jpg" alt="cyclisme">
              <h3>Article 5</h3>
              <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit.Lorem ipsum dolor, sit amet consectetur adipisicing elit.</p>
              <div id="menublog">
                <ul>
                    <li><a href="#">+ d'info</a></li>
                </ul>
              </div>
          </article>
          <article class="postblog">
              <img src="images-gym/pic15.jpg" alt="cyclisme">
              <h3>Article 6</h3>
              <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit.Lorem ipsum dolor, sit amet consectetur adipisicing elit.</p>
              <div id="menublog">
                <ul>
                    <li><a href="#">+ d'info</a></li>
                </ul>
              </div>
          </article>
      </section>

      <p class="pagination1">Page précédente - <span class="pagination2">1/1</span> - Page suivante</p>




    </div>
    </main>

<?php
include('footer.php');
?>