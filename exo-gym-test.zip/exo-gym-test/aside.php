<aside id="bottom" class="pagewidth">
                <div class="column">
                    <h3>Newsletter</h3>
                    <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. 
                        Cumque odit nihil magni inventore optio reprehenderit.</p>
                        <form action="enregistrermail.php" method="POST">
                            <input type="email" name="email" placeholder="Tapez votre Email">
                            <input type="submit" value="ENVOYER        >" >         
                        </form>
                </div>
                <div class="column">
                    <img src="images-gym/logo.png" alt="salle">
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. 
                        Veniam ea vitae et neque! Ipsa, iste consectetur </p>
                    <p>Phone: <a href="tel:+33297979797">+ 33 2 97 97 97 97</a></p>
                    <p>Email: <a href="mailto:nfo@gym.com">info@gym.com</a></p>
                </div>
                <div class="column">
                    <ul>
                        <h3>Menu</h3>
                        <li><a href="#"><i class="fas fa-chevron-right"></i> A propos</a></li>
                        <li><a href="#"><i class="fas fa-chevron-right"></i> Parcours</a></li>
                        <li><a href="#"><i class="fas fa-chevron-right"></i> Cours</a></li>
                        <li><a href="#"><i class="fas fa-chevron-right"></i> Prix</a></li>
                        <li><a href="#"><i class="fas fa-chevron-right"></i> Infos légales</a></li>
                        <li><a href="contact.php"><i class="fas fa-chevron-right"></i> Contact</a></li>
                    </ul>

                    <ul>
                        <h3>Communauté</h3>
                        <li><a href="blog.php"><i class="fas fa-chevron-right"></i> Blog</a></li>
                        <li><a href="#"><i class="fas fa-chevron-right"></i> Forum</a></li>
                        <li><a href="#"><i class="fas fa-chevron-right"></i> Support</a></li>
                        <li><a href="#"><i class="fas fa-chevron-right"></i> Newsletter</a></li>
                    </ul>
                </div>
            </aside>