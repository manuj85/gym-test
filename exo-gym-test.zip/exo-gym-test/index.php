<?php
include('header.php');
?>


    <main id="content">
      <div class="pagewidth">
        <div id="welcome">
            <img src="images-gym/visuel-accueil.png" alt="Gym">
            <div class="textblock">
            <h1>En forme avant l'été</h1>
            <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. 
                Ab rem, dolor eveniet quibusdam</p>
            </div>
        </div>
      

      <section id="articles">

          <article class="post">
              <h3><span class="bold">Live</span> Cyclisme</h3>
              <h4>Salle 2</h4>
              <img src="images-gym/cyclisme.jpg" alt="cyclisme">
          </article>
          <article class="post">
            <h3><span class="bold">Live</span> Gym</h3>
            <h4>Salle 1</h4>
            <img src="images-gym/gym.jpg" alt="gym">
          </article>
          <article class="post">
            <h3><span class="bold">Live</span> Pilates</h3>
            <h4>Salle 4</h4>
            <img src="images-gym/pilates.jpg" alt="pilates">
          </article>
      </section>

      <section id="galleries">
          <figure id="gallery">
              <figcaption><h2>Galerie</h2></figcaption>
              <img src="images-gym/galerie1.jpg" alt="galerie 1">
              <img src="images-gym/galerie2.jpg" alt="galerie 2">
              <img src="images-gym/galerie3.jpg" alt="galerie 3">
              <img src="images-gym/galerie4.jpg" alt="galerie 4">
          </figure>
          <figure id="partners">
            <figcaption><h2>Partenaires</h2></figcaption>
            <a href="#"><img src="images-gym/p1.png" alt="p 1"></a>
            <a href="#"><img src="images-gym/p2.png" alt="p 2"></a>
            <a href="#"><img src="images-gym/p3.png" alt="p 3"></a>
            <a href="#"><img src="images-gym/p4.png" alt="p 4"></a>
            <a href="#"><img src="images-gym/p5.png" alt="p 5"></a>
            <a href="#"><img src="images-gym/p6.png" alt="p 6"></a>
        </figure>
      </section>



    </div>
    </main>

<?php
include('footer.php');
?>