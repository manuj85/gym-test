<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>PHP - Exo gym, votre espace bien-être</title>
    <meta name="description" content="Exo gym, club sportif">
    <!--feuilles de style-->
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans+Condensed:wght@300&family=Open+Sans:wght@300&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style2.css">
    
</head>
<body>
    <header id="banner">
        <div id="telephone">
            <div class="pagewidth">
            <a href="tel:+33297979797"><i class="fas fa-phone-alt"></i> +33 2 97 97 97 97</a>
            </div>
        </div>

        <div class="pagewidth flexmenu">
            <figure id="logo"><a href="index.php"><img src="images-gym/logo.png" alt="www.exo-gym.com"></a></figure>
            <nav id="menuprincipal">
                <ul>
                    <li><a href="index.php" class="on">Accueil</a></li>
                    <li><a href="#">A propos</a></li>
                    <li><a href="#">Parcours</a></li>
                    <li><a href="#">Cours</a></li>
                    <li><a href="blog.php">Blog</a></li>
                    <li><a href="#">Prix</a></li>
                    <li><a href="contact.php">Contact</a></li>
                </ul>
            </nav>
        </div>
    </header>